# 部署说明

## 本地运行

1. 安装依赖
```bash
npm install
```

2. 启动开发服务器
```bash
npm run dev
```

3. 构建生产版本
```bash
npm run build
```

## 部署到 GitHub Pages

1. 构建项目
```bash
npm run build
```

2. 推送到 gh-pages 分支
```bash
git init
git add .
git commit -m "Deploy to GitHub Pages"
git branch -M main
git remote add origin https://github.com/your-username/your-repo.git
git push -u origin main
```

## 部署到 Vercel

1. 安装 Vercel CLI
```bash
npm i -g vercel
```

2. 部署
```bash
vercel
```

## 部署到 Netlify

1. 构建项目
```bash
npm run build
```

2. 将 dist/ 目录拖拽到 Netlify 仪表板

## 注意事项

- 确保 Node.js 版本 >= 18
- 生产构建输出在 dist/ 目录
- 所有静态资源已包含在 public/ 目录
